package com.stash.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StashBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(StashBackendApplication.class, args);
	}

}
